### plaid-python quickstart

[Quickstart guide](https://plaid.com/docs/quickstart)

``` bash
git clone https://github.com/plaid/quickstart.git
cd quickstart/python
pip install -r requirements.txt

# Fill in your Plaid API keys (client ID, secret, public_key)
# in server.py to test!
python server.py
# Go to http://localhost:5000
```
